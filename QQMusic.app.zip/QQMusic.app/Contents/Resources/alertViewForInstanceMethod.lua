waxClass{"WaxTestObject", NSObject}

function showInstanceAlertView(self, msg)
    ComHelper:showIKnownAlertWithMessage("这是一个实例方法:Lua替换")
end