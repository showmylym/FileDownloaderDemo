waxClass{"WaxTestObject", NSObject}

function showAlertView(self, msg)
    ComHelper:showIKnownAlertWithMessage("这是一个类方法:Lua替换")
end