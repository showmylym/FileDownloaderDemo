waxClass{"WaxTestObject", NSObject}

function init(self)
    wax.print("[WAXTEST] WaxTestObject Lua init")
    local retSelf = self:ORIGinit()
    retSelf:setInitByLua(true)
    return retSelf
end

function initForLua(self)
    wax.print("[WAXTEST] WaxTestObject Lua initForLua")
    local retSelf = WaxTestObject:init()
    retSelf:setInitByLua(true)
    retSelf:retain()
    return retSelf
end

function callOCInit(self)
    wax.print("[WAXTEST] WaxTestObject Lua callOCInit")
    local object = NSObject:init()
    return object
end

function retVoidMethodWithVoidParam(self)
    wax.print("[WAXTEST] WaxTestObject Lua retVoidMethodWithVoidParam")
    self:ORIGretVoidMethodWithVoidParam()
    self:setIsRetVoidMethodWithVoidParam(true)
end

function retWaxTestObjectWithNumber_andDic_andCGRect_andFloat(self, number, dic, rect, floatNum)
    wax.print("[WAXTEST] WaxTestObject Lua retWaxTestObjectWithNumber_andDic_andCGRect_andFloat")
    return self:ORIGretWaxTestObjectWithNumber_andDic_andCGRect_andFloat(number, dic, rect, floatNum)
end

function retFloatSumMethod_andB(self, a, b)
    wax.print("[WAXTEST] WaxTestObject Lua retFloatSumMethod_andB")
    return self:ORIGretFloatSumMethod_andB(a+1, b+1)
end

function retNumberSumMethod_andB(self, a, b)
    wax.print("[WAXTEST] WaxTestObject Lua retNumberSumMethod_andB")
    return self:ORIGretNumberSumMethod_andB(a+1, b+1)
end

function retDicWithDict(self, dic)
    wax.print("[WAXTEST] WaxTestObject Lua retDicWithDict")
    local newDic = {}
    newDic["a"] = dic["a"]
    newDic["c"] = dic["c"]
    newDic["e"] = "f"
    return self:ORIGretDicWithDict(newDic)
end

function retCGRectMethodWithCGRect(self, rect)
    wax.print("[WAXTEST] WaxTestObject Lua retCGRectMethodWithCGRect")
    return self:ORIGretCGRectMethodWithCGRect(CGRect(101,202,303,404))
end

function blockParamMethod(self, block)
    wax.print("[WAXTEST] WaxTestObject Lua blockParamMethod")
    return self:ORIGblockParamMethod(block)
end

function retArrayMethodWithParam1_param2_param3_param4_param5_param6_param7_param8_param9_param10(self, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
    wax.print("[WAXTEST] WaxTestObject Lua retArrayMethodWithParam1_param2_param3_param4_param5_param6_param7_param8_param9_param10")
    return self:ORIGretArrayMethodWithParam1_param2_param3_param4_param5_param6_param7_param8_param9_param10(0, param2, param3, param4, param5, param6, param7, param8, param9, param10)
end

function retArrayClassMethodWithParam1_param2_param3_param4_param5_param6_param7_param8_param9_param10(self, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
    wax.print("[WAXTEST] WaxTestObject Lua retArrayClassMethodWithParam1__param2_param3_param4_param5_param6_param7_param8_param9_param10")
    return self:ORIGretArrayClassMethodWithParam1_param2_param3_param4_param5_param6_param7_param8_param9_param10(11, param2, param3, param4, param5, param6, param7, param8, param9, param10)
end